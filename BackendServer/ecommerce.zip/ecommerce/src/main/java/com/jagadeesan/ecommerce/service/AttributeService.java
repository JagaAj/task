package com.jagadeesan.ecommerce.service;

import com.jagadeesan.ecommerce.model.Attribute;
import com.jagadeesan.ecommerce.model.Category;
import com.jagadeesan.ecommerce.repository.AttributeRepository;
import com.jagadeesan.ecommerce.repository.CategoryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AttributeService {

    @Autowired
    private AttributeRepository attributeRepo;

    @Autowired
    private CategoryRepository categoryRepo;

    public List<Attribute> getAttributesByCategoryId(Long categoryId) {
        if (!categoryRepo.existsById(categoryId)) {
            throw new RuntimeException("Category not found");
        }
        return attributeRepo.findByCategoryId(categoryId);
    }

    public Attribute addAttribute(Long categoryId, Attribute attr) {
        Category category = categoryRepo.findById(categoryId)
                .orElseThrow(() -> new RuntimeException("Category not found"));
        attr.setCategory(category);
        return attributeRepo.save(attr);
    }

    public Attribute updateAttribute(Long attrId, Attribute attrDetails) {
        Attribute attr = attributeRepo.findById(attrId)
                .orElseThrow(() -> new RuntimeException("Attribute not found"));
        attr.setName(attrDetails.getName());
        attr.setDataType(attrDetails.getDataType());
        return attributeRepo.save(attr);
    }

    public void deleteAttribute(Long attrId) {
        if (!attributeRepo.existsById(attrId)) {
            throw new RuntimeException("Attribute not found");
        }
        attributeRepo.deleteById(attrId);
    }
}
