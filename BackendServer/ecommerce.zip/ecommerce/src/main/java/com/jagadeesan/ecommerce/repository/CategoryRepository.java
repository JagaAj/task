package com.jagadeesan.ecommerce.repository;

import com.jagadeesan.ecommerce.model.Category;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CategoryRepository extends JpaRepository<Category,Long> {
}
