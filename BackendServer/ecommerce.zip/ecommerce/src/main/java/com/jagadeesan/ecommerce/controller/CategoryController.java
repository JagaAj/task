package com.jagadeesan.ecommerce.controller;

import com.jagadeesan.ecommerce.model.Attribute;
import com.jagadeesan.ecommerce.model.Category;
import com.jagadeesan.ecommerce.service.AttributeService;
import com.jagadeesan.ecommerce.service.CategoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/categories")
@CrossOrigin(origins ="http://localhost:3000/")

public class CategoryController {

    @Autowired
    private CategoryService categoryService;

    @Autowired
    private AttributeService attributeService;

    @GetMapping
    public List<Category> getAllCategories() {
        return categoryService.getAllCategories();
    }

    @PostMapping
    public Category createCategory(@RequestBody Category category) {
        return categoryService.createCategory(category);
    }

    @PutMapping("/{id}")
    public Category updateCategory(@PathVariable Long id, @RequestBody Category category) {
        return categoryService.updateCategory(id, category);
    }

    @GetMapping("/{id}/attributes")
    public List<Attribute> getAttributes(@PathVariable Long id) {
        return attributeService.getAttributesByCategoryId(id);
    }

    @PostMapping("/{id}/attributes")
    public Attribute addAttribute(@PathVariable Long id, @RequestBody Attribute attr) {
        return attributeService.addAttribute(id, attr);
    }

    @PutMapping("/attributes/{attrId}")
    public Attribute updateAttribute(@PathVariable Long attrId, @RequestBody Attribute attr) {
        return attributeService.updateAttribute(attrId, attr);
    }

    @DeleteMapping("/attributes/{attrId}")
    public void deleteAttribute(@PathVariable Long attrId) {
        attributeService.deleteAttribute(attrId);
    }
}
