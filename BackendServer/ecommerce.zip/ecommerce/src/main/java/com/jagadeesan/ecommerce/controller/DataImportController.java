package com.jagadeesan.ecommerce.controller;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.jagadeesan.ecommerce.model.Product;
import com.jagadeesan.ecommerce.repository.ProductRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;

@RestController
public class DataImportController {


    @Autowired
    private ProductRepo productRepo;


    @PostMapping("/products/import")
    public String importData() {
        ObjectMapper objectMapper = new ObjectMapper();
        TypeReference<List<Product>> typeReference = new TypeReference<List<Product>>() {};
        InputStream inputStream = null;
        try {
            inputStream = new ClassPathResource("products.json").getInputStream();
            List<Product> products = objectMapper.readValue(inputStream, typeReference);
            productRepo.saveAll(products);
            return "Data imported successfully!";
        } catch (IOException e) {
            return "Error occurred: " + e.getMessage();
        }
    }
}
