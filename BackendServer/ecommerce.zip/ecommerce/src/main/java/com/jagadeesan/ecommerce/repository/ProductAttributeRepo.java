package com.jagadeesan.ecommerce.repository;

import com.jagadeesan.ecommerce.model.ProductAttribute;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.transaction.annotation.Transactional;

public interface ProductAttributeRepo extends JpaRepository<ProductAttribute, Long> {
    @Transactional
    void deleteByProductId(Long productId);
}
