package com.jagadeesan.ecommerce.service;

import com.jagadeesan.ecommerce.model.Product;
import com.jagadeesan.ecommerce.model.ProductAttribute;
import com.jagadeesan.ecommerce.repository.ProductAttributeRepo;
import com.jagadeesan.ecommerce.repository.ProductRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;

import java.util.List;

@Service
public class ProductService {

    @Autowired
    private ProductRepo productRepo;
    @Autowired
    private ProductAttributeRepo attributeRepo;

    public List<Product> getAllProduct() {
        return productRepo.findAll();
    }

    public Product getProductById(Long id) {
        return productRepo.findById(id).orElse(null);
    }

    public void deleteProduct(Long id) {
        attributeRepo.deleteByProductId(id);
        productRepo.deleteById(id);
    }


public Product addProduct(Product product, MultipartFile imageFile) throws IOException {
    if (imageFile != null && !imageFile.isEmpty()) {
        product.setImageName(imageFile.getOriginalFilename());
        product.setImageType(imageFile.getContentType());
        product.setImageData(imageFile.getBytes());
    }

    if (product.getAttributes() != null) {
        for (ProductAttribute attr : product.getAttributes()) {
            attr.setProduct(product);
        }
    }

    return productRepo.save(product);
}


    public List<Product> searchProducts(String keyword) {
        return productRepo.searchProducts(keyword);
    }


    public Product updateProduct(Long id, Product updatedProduct, MultipartFile imageFile) throws IOException {
        Product existingProduct = productRepo.findById(id)
                .orElseThrow(() -> new RuntimeException("Product not found"));

        if (updatedProduct.getName() != null) existingProduct.setName(updatedProduct.getName());
        if (updatedProduct.getDescription() != null) existingProduct.setDescription(updatedProduct.getDescription());
        if (updatedProduct.getPrice() != null) existingProduct.setPrice(updatedProduct.getPrice());
        if (updatedProduct.getCategory() != null) existingProduct.setCategory(updatedProduct.getCategory());
        if (updatedProduct.getStockQuantity() != null) existingProduct.setStockQuantity(updatedProduct.getStockQuantity());

        if (imageFile != null && !imageFile.isEmpty()) {
            existingProduct.setImageName(imageFile.getOriginalFilename());
            existingProduct.setImageType(imageFile.getContentType());
            existingProduct.setImageData(imageFile.getBytes());
        }

        if (updatedProduct.getAttributes() != null) {
            existingProduct.getAttributes().clear();
            updatedProduct.getAttributes().forEach(attr -> attr.setProduct(existingProduct));
            existingProduct.getAttributes().addAll(updatedProduct.getAttributes());
        }

        return productRepo.save(existingProduct);
    }

}