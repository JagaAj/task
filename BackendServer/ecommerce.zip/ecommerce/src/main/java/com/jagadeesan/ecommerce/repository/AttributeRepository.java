package com.jagadeesan.ecommerce.repository;

import com.jagadeesan.ecommerce.model.Attribute;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface AttributeRepository extends JpaRepository<Attribute,Long> {
    List<Attribute> findByCategoryId(Long categoryId);
}
